---
name: Luminescent Precision
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e7'
  on-surface-variant: '#c5c7c9'
  inverse-surface: '#e4e1e7'
  inverse-on-surface: '#303034'
  outline: '#8f9194'
  outline-variant: '#44474a'
  surface-tint: '#c6c6c8'
  primary: '#ffffff'
  on-primary: '#2f3132'
  primary-container: '#e2e2e4'
  on-primary-container: '#636466'
  inverse-primary: '#5d5e60'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#ffffff'
  on-tertiary: '#00354a'
  tertiary-container: '#c4e7ff'
  on-tertiary-container: '#006c93'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e4'
  primary-fixed-dim: '#c6c6c8'
  on-primary-fixed: '#1a1c1d'
  on-primary-fixed-variant: '#454749'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#131317'
  on-background: '#e4e1e7'
  surface-variant: '#353439'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1.25rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a premier multi-vendor marketplace atmosphere defined by Apple-grade engineering, restrained luxury, and absolute clarity. The brand targets design-conscious consumers and curated high-end vendors who demand an editorial, distraction-free transactional environment. 

The aesthetic is a synthesis of Hyper-Minimalism and Advanced Glassmorphism:
- **Atmospheric Depth:** Frosted glass materials (`backdrop-filter: blur(20px)`), luminous edges, and delicate inner light rimming create physical weight and clarity without clutter.
- **Controlled Interaction:** Zero ornamental noise. Every visual cue—from hover transitions to scroll physics—leverages natural friction, ease-out curves, and subtle micro-glows.
- **Editorial Presentation:** Generous negative space frames high-resolution product photography, letting objects command the screen like gallery pieces.

## Colors

The palette balances monochromatic neutrality with crystalline luminescent highlights.

- **Primary (`#F5F5F7`):** Refined soft platinum. Used for primary typography, crisp foreground highlights, and inverted solid interactive elements in dark mode.
- **Secondary (`#6366F1`):** Electric Indigo. Deployed sparingly for focused active states, interactive confirmations, checkout accents, and delicate ambient underglows.
- **Tertiary (`#38BDF8`):** Celestial Cyan. Reserved for subtle gradient shifts, fine status badges, and specular rim reflections.
- **Neutral (`#0D0D11`):** Deep Obsidian. The default canvas ground, paired with graduated translucent tiers (`rgba(255, 255, 255, 0.04)` to `rgba(255, 255, 255, 0.12)`) to formulate frosted glass plates.

### Light & Dark Paradigm
- **Dark Mode (Default):** Canvas uses `#0D0D11` with floating glass tiers, deep charcoal containers (`#16161D`), and 1px white border passes at 8–14% opacity.
- **Light Mode Adaptation:** Background flips to pure studio white (`#FAFAFC`), surfaces shift to milky translucent glass (`rgba(255, 255, 255, 0.75)` with `rgba(0, 0, 0, 0.06)` border strokes), and primary text renders in deep graphite (`#1D1D1F`).

## Typography

The typographic hierarchy is balanced between the structural elegance of Plus Jakarta Sans for titles and the neutral legibility of Inter for dense commerce interfaces.

- **Display & Headlines:** Plus Jakarta Sans features geometric precision with subtle humanist softening, providing optical authority in editorial marketplace spreads. Tight negative letter-spacing ensures a crisp, polished appearance at high scale.
- **Body & Product Metadata:** Inter governs product specs, order tables, pricing, and descriptions. Standard tracking ensures total legibility against translucent surfaces and high-contrast imagery.
- **Micro-Labels & Badges:** `label-sm` utilizes uppercase rendering with expanded letter-spacing (`0.04em`) to establish crisp technical annotations, vendor verification badges, and currency indicators.

## Layout & Spacing

The layout is anchored to a 12-column responsive fluid grid with maximum content bounding at 1440px to retain an intimate, gallery-curated scale.

### Responsive Breakpoints
- **Mobile (< 768px):** 4 columns, `margin-mobile` (1.25rem / 20px), `gutter-sm` (1rem / 16px). Product listings stack to a single column or 2-column compact browse grid.
- **Tablet (768px – 1024px):** 8 columns, `margin` (2rem / 32px), `gutter` (1.5rem / 24px). Horizontal dual-pane interfaces for cart and checkout previews.
- **Desktop (> 1024px):** 12 columns, `margin-desktop` (4rem / 64px), `gutter-lg` (2rem / 32px). Expansive asymmetrical arrangements balancing vendor storytelling on 7 columns and sticky checkout/specifications on 5 columns.

### Spacing Philosophy
Rhythm follows an 8px base unit (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 16px, `space-lg` = 24px, `space-xl` = 40px). Section separations rely on open negative space rather than heavy separator lines.

## Elevation & Depth

Visual hierarchy rejects harsh drop shadows in favor of ambient multi-stop diffusion, luminous rim borders, and frosted glass layers.

### Surface Tiers
- **Tier 0 (Base Canvas):** Solid neutral ground (`#0D0D11`).
- **Tier 1 (Resting Cards & Surfaces):** Translucent fill `rgba(255, 255, 255, 0.03)` with `backdrop-filter: blur(24px) saturate(180%)`. Border: 1px solid `rgba(255, 255, 255, 0.08)`. Shadow: `0 4px 20px -2px rgba(0, 0, 0, 0.3)`.
- **Tier 2 (Floating Trays & Modals):** Translucent fill `rgba(255, 255, 255, 0.07)` with `backdrop-filter: blur(40px) saturate(200%)`. Border: 1px solid `rgba(255, 255, 255, 0.15)`. Shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.5)`.
- **Tier 3 (Active Focus & Glows):** Subtle violet/indigo underglow: `box-shadow: 0 0 28px -4px rgba(99, 102, 241, 0.25), 0 1px 0 0 rgba(255, 255, 255, 0.2) inset`.

### Light Inset & Rim Lighting
Every elevated glass panel incorporates a top-edge 1px inner highlight (`inset 0 1px 0 0 rgba(255, 255, 255, 0.15)`) mimicking a bevel catching direct overhead light.

## Shapes

The interface utilizes continuous curvature (squircle-inspired geometry) at roundedness level `2`.

- **Base Radius (0.5rem / 8px):** Inputs, small tags, tooltips, and badges.
- **Large Radius (`rounded-lg`, 1rem / 16px):** Primary buttons, drop-down menus, vendor mini-profiles, and secondary containers.
- **Extra Large Radius (`rounded-xl`, 1.5rem / 24px):** Product hero cards, marketplace panels, modals, and sticky action docks.
- **Pill Exceptions:** Search bars, checkout floating pill navigators, and filter pills explicitly override to full rounded capsules (`9999px`).

## Components

### Buttons
- **Primary Action:** Solid soft platinum (`#F5F5F7`) fill with Obsidian (`#0D0D11`) text, `rounded-lg`, font weight 600. On hover: scaled slightly (`transform: scale(1.015)`) with an ethereal violet glow (`0 0 20px rgba(99, 102, 241, 0.3)`).
- **Secondary (Glass):** `rgba(255, 255, 255, 0.05)` surface, 1px border `rgba(255, 255, 255, 0.12)`, backdrop-blur 16px. On hover: border brightens to `rgba(255, 255, 255, 0.25)` and background to `rgba(255, 255, 255, 0.09)`.
- **Ghost/Tertiary:** Zero background, muted gray text, reveals a soft glass pill on hover.

### Product & Vendor Cards
- **Structure:** Frosted glass Tier 1 shell (`rounded-xl`). Edge-to-edge subtle top inner highlight. Image container uses a calibrated dark neutral stage (`#13131A`) with smooth object containment.
- **Hover Micro-interaction:** The card shifts upwards 3px (`transition: transform 300ms cubic-bezier(0.16, 1, 0.3, 1)`), borders shift from 8% to 18% opacity, and an ultra-soft indigo ambient glow appears beneath the card base.

### Form Inputs & Search Fields
- **Resting:** Inset glass trough (`rgba(255, 255, 255, 0.03)`), border `rgba(255, 255, 255, 0.08)`, text `#F5F5F7`.
- **Focus:** Border transitions smoothly to `#6366F1` at 60% opacity with a focused ring glow (`0 0 0 3px rgba(99, 102, 241, 0.15)`).

### Selection Controls (Checkboxes & Radios)
- Custom rounded squares (`rounded: 6px`) and circular rings. Unselected: 1px border `rgba(255, 255, 255, 0.2)`. Selected: `#6366F1` gradient fill with a crisp white tick/dot icon and a soft 8px blur underglow.

### Filter & Category Chips
- Pill geometry with `backdrop-filter: blur(12px)`. Inactive: semi-transparent charcoal with muted text. Active: solid `rgba(255, 255, 255, 0.14)` with white text and a 1px border `rgba(255, 255, 255, 0.3)`.

### Market-Specific Components
- **Vendor Verified Badge:** Translucent violet pill containing an SVG seal icon and vendor rating score.
- **Sticky Glass Checkout Dock:** Floating bottom navigation bar across mobile and desktop checkout flows, featuring `backdrop-filter: blur(32px)`, dynamic order summary totals, and streamlined Apple Pay / one-tap purchase triggers.